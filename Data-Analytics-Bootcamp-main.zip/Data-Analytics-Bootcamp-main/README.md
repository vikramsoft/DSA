# CONGRATULATIONS!! 

You've successfully completed the Alex Analytics Data Analyst Bootcamp!

Well, we can just call it the Data Analytics Bootcamp to keep things simple :) 

Go ahead and download the certifications in this repository! You've earned it! We use the honors system here.

#### I hope it helps you land a job in Analytics!

Data Analytics Bootcamp Link: https://www.youtube.com/playlist?list=PLUaB-1hjhk8FE_XZ87vPPSfHqb6OcM0cF

.

.

.

.

.

*Note: This Certificate is not my endorsement for a job. I can not vouch for you as an analyst, individual, or professional. Certifications are not legally binding or a contractual agreement of any kind. This Certification is a self-verification that you completed the entire Data Analyst Bootcamp playlist on Alex The Analyst YouTube channel.
